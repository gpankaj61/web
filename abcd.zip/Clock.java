import java.awt.*;
import java.applet.*;
import java.util.*;
import java.text.*;

public class Clock extends Applet {
	int sx = 0,sy = 0,mx = 0,my = 0,hx = 0,hy = 0;
	int sradius = 100, cx = 300, cy = 300, mradius = 70, hradius = 40;
	double sangle = 0.0,mangle = 0.0,hangle = 0.0;

	public void init(){
		
      	SimpleDateFormat ft = new SimpleDateFormat ("hh:mm:ss");
      	String str[] = new String[3];
      	String now = ft.format(new Date());
      	str = now.split(":");
      	int hr = Integer.parseInt(str[0]);
      	int min = Integer.parseInt(str[1]);
      	int sec = Integer.parseInt(str[2]);

      	System.out.println(""+sec+":"+min+":"+hr);

      	sangle = (Math.PI/30)*sec + Math.PI/2;
      	mangle = (Math.PI/30)*min + (Math.PI/1800)*sec + Math.PI/2;
      	hangle = (Math.PI/6)*hr + (Math.PI/360)*min + (Math.PI/21600)*sec + Math.PI/2;
		

	}
	public void paint(Graphics g) {
		sy = cy - (int)(Math.sin(sangle)*sradius);
		sx = cx - (int)(Math.cos(sangle)*sradius);

		my = cy - (int)(Math.sin(mangle)*mradius);
		mx = cx - (int)(Math.cos(mangle)*mradius);

		hy = cy - (int)(Math.sin(hangle)*hradius);
		hx = cx - (int)(Math.cos(hangle)*hradius);

		g.drawOval(cx-100,cy-100,sradius*2,sradius*2);
		g.drawOval(cx-119,cy-119,sradius*2+38,sradius*2+38);
		g.drawLine(cx, cy, sx, sy);
		g.drawLine(cx, cy, mx, my);
		g.drawLine(cx, cy, hx, hy);
		g.drawString("12",295,195);
		g.drawString("9",190,300);
		g.drawString("6",300,410);
		g.drawString("3",402,302);
		/*g.drawString("12",300 199);
		g.drawString("12",300 199);
		g.drawString("12",300 199);
		g.drawString("12",300 199);	
*/
		try {
			Thread.sleep(1000);
		}catch(Exception e){

		}
		sangle += (Math.PI/30);
		hangle += (Math.PI/21600);
		mangle += (Math.PI/1800);
		repaint();
	}
}
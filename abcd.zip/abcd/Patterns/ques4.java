/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
public class ques4 {
	public static void main(String[] args) {
		int i,j;
		for(i=1; i<=6; i++)
		{
			for(j=1; j<i; j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*; 
class ques14 
{ 
	public static void main(String args[]) throws IOException 
	{ 
		char c; 
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
		System.out.println("Enter characters, 'q' to quit."); 
		// read characters 
		char result='a';
                do 
		{ 
			c = (char) br.read(); 
			
			if (result < c && c!='q')
			{
				result=c;
			}
						
		} 
		while(c != 'q'); 
		System.out.println(result); 
	} 
}

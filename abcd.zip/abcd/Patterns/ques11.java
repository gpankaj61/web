/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.util.*;
public class ques11 
{
   public static void main(String[] args) 
   {
      int n = 6;
      for (int row = 0; row < n; row++) 
      {
        for (int column = 0; column < n; column++) 
        {
            if (row == 0 || row == n - 1 || column == n - 1 - row) 
            {
                System.out.print("*");
            } 
            else 
            {
                System.out.print(" ");
            }
        }
        System.out.println();
      }
   }
}
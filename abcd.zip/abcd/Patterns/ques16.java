/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
public class ques16 
{
    public static void main(String args[])
    {
        int i = 1 ;
        double sum = 0;
        while(i <= 100)
        {
            sum = sum +(1/(double)i);
            i++;
        }
        System.out.println("Sum of Resiprocal of First 100 Natural Numbers:"+sum);
    } 
}
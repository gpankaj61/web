/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
public class ques7 {
    public static void main(String[] args) {
        int row,temp, c,n=5;
            temp = n;
            for ( row = 1 ; row <= n ; row++ )
               {
                  for ( c = 1 ; c < temp ; c++ )
                    System.out.print(" ");

                  temp--;

                  for ( c = 1 ; c <= 2*row - 1 ; c++ )
                      System.out.print("*");

                  System.out.println("");
               }
        }

    }
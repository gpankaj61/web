/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
public class ques13 
{
	public static void main( String arg[]){
		int rows = 5; //change rows accordingly
		int cout = 1;
		for(int i=1;i<=rows;i++)
		{
			for(int j=0;j<i;j++)
			{
				System.out.print(cout+" ");
				cout++;
			}
			System.out.println();
		}
	}
}
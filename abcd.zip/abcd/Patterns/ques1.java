/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
public class ques1 
{
    public static void main( String arg[])
    {
        for(int i=1;i<=5;i++)
        {
            for(int j=1;j<=i;j++)
            {
                System.out.print(j);
            }
            System.out.println();
        }
    }
}
/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.util.Scanner;
public class ques15 
{
	public static void main(String[] arg)
    {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Enter first term, common ratio and n (number of terms)");
    	int a=sc.nextInt(),r=sc.nextInt(),n=sc.nextInt();
    	System.out.print("\n"+a);
    	for(int i=1;i<n;i++)
        	System.out.print(" "+(a*=r));
    }
}
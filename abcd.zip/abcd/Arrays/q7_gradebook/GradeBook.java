/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;



class GradeBook {
    String name[];
    int marks[][];
    char grade[];

    public GradeBook() {
        this.name = new String[5];
        this.marks = new int[5][4];
        grade = new char[4];
    }
    
    public void calGrade()
    {
        double sum = 0;
        for(int i=0;i<5;i++)
        {
            sum=marks[i][0]+marks[i][1]+marks[i][2]+marks[i][3];
            grade[i]=grades(sum/4);
        }
    }

    public void setMarks() throws IOException {
        BufferedReader br =new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the marks :");
        for(int i=0;i<5;i++){
            System.out.println(" Student "+(i+1)+" : ");
            for(int j=0;j<4;j++){
                System.out.println("Subject "+(j+1)+":");
                marks[i][j] = Integer.parseInt(br.readLine()); 
            }
        }
    }

    public void setName() throws IOException {
        BufferedReader br =new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the names :");
        for(int i=0;i<5;i++){
            System.out.println("Student "+(i+1)+": ");
            name[i] = br.readLine();
        }
    }


    char grades(double marks)
    {
            char grade;
            if(marks >= 90){
                grade = 'A';
            }
            else 
            if(marks >= 80){
                grade = 'B';
            }
            else
            if(marks >= 70){
                grade = 'C';
            }
            else
            if(marks >= 60){
                grade = 'D';
            }
            else
            {
                grade='F';
            }
            return grade;
    }
    
    void display(){
        System.out.println("The Result is : ");
        for(int i=0;i<5;i++){
            
        System.out.println("Student "+(i+1)+": "+name[i]+" : "+grade[i]);
        }
    }
    public static void main(String args[]) throws IOException{
        
        GradeBook gb = new GradeBook();
        gb.setName();
        gb.setMarks();
        gb.calGrade();
    }
}
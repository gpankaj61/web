/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
class AccVal{
private String[] acc={"5658845","4520125","7895122","8777541","8451277","1302850","8080152","4562555","5552012","5050552","7825877","1250255","L00523L","6545231","3852085","7576651","7881200","4581002"};
	
public  boolean ifValid(String val){
	for(String str:acc){
		if(str.equals(val))
			return true;
	}
	return false;
}
	public static void main(String[] args)
	{
		AccVal accVal=new AccVal();
		String acc=new String();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter charge account number:");
		acc=sc.next();
		if(accVal.ifValid(acc)==true)
			System.out.println("Valid");
		else
			System.out.println("InValid");
	}
}
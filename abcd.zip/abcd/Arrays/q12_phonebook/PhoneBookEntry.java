/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.ArrayList;

class PhoneBookEntry {

    String name;
    long number;
    public PhoneBookEntry() {
    }

    public PhoneBookEntry(String name, long number) {
        this.name = name;
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getNumber() {
        return number;
    }

    public void setNumber(long number) {
        this.number = number;
    }
    
    public static void main(String args[]) throws IOException
    {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
        ArrayList ar = new ArrayList();
        for (int i=0;i < 5;i++)
        {
            System.out.print("Enter the name : ");
            String name = br.readLine();
            
            System.out.print("Enter the number : ");
            long num = Long.parseLong(br.readLine());
            ar.add(new PhoneBookEntry(name,num));
        }
        for(int i=0;i<5;i++)
        {
            System.out.println(((PhoneBookEntry)ar.get(i)).name + " :  "
                    + ((PhoneBookEntry)ar.get(i)).number);
        }
    }
}
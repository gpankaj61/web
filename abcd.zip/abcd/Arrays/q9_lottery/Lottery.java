/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;



class Lottery {
    int ar[];
    final int size = 5;
    public Lottery() {
        this.ar = new int[5];
        for(int i=0;i<size; i++){
            ar[i] = (int) (Math.random()*10);
        }
    }
    
    public int checkLottery(int b[])
    {
        int c =0 ;
        for(int i=0;i<size;i++)
        {
            if(ar[i]==b[i]) c++;
        }
        return c;
    }
    
    public static void main(String args[]) throws IOException
    {
        int arr[] = new int[5];
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter The elements of array (5) : ");
        for(int i=0;i<5;i++){
            arr[i] = Integer.parseInt(br.readLine());
        }
        Lottery l =new Lottery();
        if(l.checkLottery(arr)==5){
            System.out.println("GRAND PRIZE WINNER!!!!");
            
        }
        System.out.println("Matches Found : "  + l.checkLottery(arr));
            
    }
    
}
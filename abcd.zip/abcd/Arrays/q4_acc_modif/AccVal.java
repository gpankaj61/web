/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
class AccVal{
private String[] acc;
AccVal(String input){
	acc=input.split("\t");
}
public  boolean ifValid(String val){
	for(String str:acc){
		if(str.equals(val))
			return true;
	}
	return false;
}
	public static void main(String[] args)
	{
		
		String acc=new String(),str=new String();
		try{
		FileReader fr=new FileReader("input.txt");
		BufferedReader br=new BufferedReader(fr);
		StringBuilder sb=new StringBuilder();
		acc=br.readLine();
		while(acc!=null)
		{
			sb.append(acc);
			acc=br.readLine();
		}
		str=sb.toString();
	}catch(IOException io)
	{
		System.out.println("error in reading file");
	}
		AccVal accVal=new AccVal(str);
		Scanner sc=new Scanner(System.in);
		System.out.println("enter charge account number:");
		acc=sc.next();
		if(accVal.ifValid(acc)==true)
			System.out.println("Valid");
		else
			System.out.println("InValid");
	}
}
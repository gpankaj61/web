/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
class Rainfall{
private double[] rain;
public Rainfall(){
	rain=new double[12];
	System.out.println("Enter rainfall for 12 months");
	Scanner sc=new Scanner(System.in);
	for(int i=0;i<12;i++)
	{
		rain[i]=sc.nextDouble();
	}
}
public double total(){
	int sum=0;
	for(int i=0;i<12;i++)
		sum+=rain[i];
	return sum;
}
public double average(){
	return total()/12;
}
public int maximum(){
	double maxi=rain[0];int in=0;
	for(int i=1;i<12;i++){
		if(rain[i]>maxi)
			{
				maxi=rain[i];
				in=i;
			}	
	}
	return in+1;
}

public int minimum(){
	double mini=rain[0];int in=0;
	for(int i=1;i<12;i++){
		if(rain[i]<mini)
			{
				mini=rain[i];
				in=i;
			}	
	}
	return in+1;
}

	public static void main(String[] args)
	{
		Rainfall a=new Rainfall();
		System.out.println("Total="+a.total()+" average="+a.average()+" maximum in ="+a.maximum()+" minimum in ="+a.minimum());
		}
}
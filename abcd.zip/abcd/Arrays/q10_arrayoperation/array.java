/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class array {
    
    public static void main(String[] args) throws IOException{
        
        int m =0;
        System.out.println("Enter the size of array : ");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        m = Integer.parseInt(br.readLine());
        
        int a[] = new int[m];
        
        System.out.println("Enter The elements of array row wise : ");
        for(int i=0;i<m;i++){
            a[i] = Integer.parseInt(br.readLine());
            
        }
        System.out.println(" Total of all elements : "+ getTotal(a,m));
        System.out.println(" Average of all elements : "+ getAverage(a,m));
        System.out.println(" Max of all elements : "+ getHighestInRow(a,m));
        System.out.println(" Min of all elements : "+ getLowestInRow(a,m));
        
    }

static int getTotal(int [] a,int m){
        
            int sum = 0;
            for(int i= 0 ; i<m;i++)
            {
                    sum+=a[i];
                
            }
            return sum;
    }

static double getAverage(int [] a,int m){
            
            int sum = 0;
            int count = 0;
            for(int i= 0 ; i<m;i++)
            {
                    sum+=a[i];
                    count++;
            }
            return (double)sum/count;
    }
static int getHighestInRow(int [] a,int m){
            int max = 0;
            for(int j = 0;j<m;j++){
                if(a[max] < a[j])
                {
                    max = j;
                }
            }
            return a[max];
    }
    
    static int getLowestInRow(int [] a,int m){
            int min = 0;
            for(int j = 0;j<m;j++){
                if(a[min] > a[j])
                {
                    min = j;
                }
            }
            return a[min];
    }


}
/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;



class array {
    
    public static void main(String[] args) throws IOException{
        
        int m =0 ,n= 0;
        System.out.println("Enter the size of matrix : ");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        m = Integer.parseInt(br.readLine());
        n = Integer.parseInt(br.readLine());
        
        int a[][] = new int[m][n];
        
        System.out.println("Enter The elements of array row wise : ");
        for(int i=0;i<m;i++){
            for(int j=0;j<n;j++){
                a[i][j] = Integer.parseInt(br.readLine());
            }
        }
        System.out.println(" Total of all elements : "+ getTotal(a,m,n));
        System.out.println(" Average of all elements : "+ getAverage(a,m,n));
        System.out.println(" Total of all row 1 elements : "+ getRowTotal(a,0,m,n));
        System.out.println(" Total of all column 2 elements : "+ getColumnTotal(a,1,m,n));
        System.out.println(" Max of all row 1 elements : "+ getHighestInRow(a,0,m,n));
        System.out.println(" Min of all row 1 elements : "+ getLowestInRow(a,0,m,n));
        
    }
    static int getTotal(int [][] a,int m,int n){
        
            int sum = 0;
            for(int i= 0 ; i<m;i++)
            {
                for(int j = 0;j < n;j++)
                {
                    sum+=a[i][j];
                }
            }
            return sum;
    }
    
    static double getAverage(int [][] a,int m,int n){
            
            int sum = 0;
            int count = 0;
            for(int i= 0 ; i<m;i++)
            {
                for(int j = 0;j<n;j++)
                {
                    sum+=a[i][j];
                    count ++;
                }
            }
            return (double)sum/count;
    }
    
    static int getRowTotal(int [][] a,int i,int m,int n){
            
        int sum=0;
        for(int j = 0;j<n;j++)
                {
                    sum+=a[i][j];
                }
        return sum;
    }
    
    static int getColumnTotal(int [][] a,int i,int m,int n){
            
        int sum=0;
        for(int j = 0;j<m;j++)
                {
                    sum+=a[j][i];
                }
        return sum;
    }
    
    static int getHighestInRow(int [][] a,int i,int m,int n){
            int max = 0;
            for(int j = 0;j<n;j++){
                if(a[i][max] < a[i][j])
                {
                    max = j;
                }
            }
            return a[i][max];
    }
    
    static int getLowestInRow(int [][] a,int i,int m,int n){
            int min = 0;
            for(int j = 0;j<n;j++){
                if(a[i][min] > a[i][j])
                {
                    min = j;
                }
            }
            return a[i][min];
    }
}
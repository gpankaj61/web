/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.ArrayList;

class Question {
	String ques;
	String a;
	String b;
	String c;
	String d;
	int res;
	
	public Question(){
		
	}
    public Question(String ques, String a, String b, String c, String d, int res) {
        this.ques = ques;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.res = res;
    }
         public static void main(String args[]) throws IOException{
             Question[]  ar = new Question[10];
             int p1=0;
             int p2=0;
             ar[0]=(new Question("What is 2+2 ?","10","22","30","4",4));
             ar[1]=(new Question("What is 2+2 ?","10","22","30","4",4));
             ar[2]=(new Question("What is 2+2 ?","10","22","30","4",4));
             ar[3]=(new Question("What is 2+2 ?","10","22","30","4",4));
             ar[4]=(new Question("What is 2+2 ?","10","22","30","4",4));
             ar[5]=(new Question("What is 2+2 ?","10","22","30","4",4));
             ar[6]=(new Question("What is 2+2 ?","10","22","30","4",4));
             ar[7]=(new Question("What is 2+2 ?","10","22","30","4",4));
             ar[8]=(new Question("What is 2+2 ?","10","22","30","4",4));
             ar[9]=(new Question("What is 2+2 ?","10","22","30","4",4));
             BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
             
                 System.out.println("\nPLAYER 1::::\n");
             for(int i=0; i<5; i++){
                 System.out.println("QUESTION : "+ar[i].ques);
                 System.out.println("1." + ar[i].a);
                 System.out.println("2." + ar[i].b);
                 System.out.println("3." + ar[i].c);
                 System.out.println("4." + ar[i].d);
                 System.out.print("Enter Your response : ");
                 int ans  = Integer.parseInt(br.readLine());
                 if(ar[i].isCorrect(ans))
                 {
                     //System.out.println("Good ! Next Question");
                     p1++;
                 }
                 
             }
             
                 System.out.println("\nPLAYER 2::::\n");
             
             for(int i=5; i<10; i++){
                 System.out.println("QUESTION : "+ar[i].ques);
                 System.out.println("1." + ar[i].ques);
                 System.out.println("2." + ar[i].ques);
                 System.out.println("3." + ar[i].ques);
                 System.out.println("4." + ar[i].ques);
                 System.out.print("Enter Your response : ");
                 int ans  = Integer.parseInt(br.readLine());
                 if(ar[i].isCorrect(ans))
                 {
                     //System.out.println("Good ! Next Question");
                     p2++;
                 }
                 
             }
             
             
            System.out.println("Player 1:"+p1+"\nPlayer 2:"+p2);
             
             if(p1 == p2)
             {
                 System.out.println("TIE!!!! ");
             }
             else if(p1 > p2)
             {
                 System.out.println("Player 1 Wins");
             }
             else System.out.println("Player 2 Wins");
             
             
         }

    public String getQues() {
        return ques;
    }

    public String getA() {
        return a;
    }

    public String getB() {
        return b;
    }

    public String getC() {
        return c;
    }

    public String getD() {
        return d;
    }
    
    public boolean isCorrect(int ans)
    {
            return ans == res;
    }
	
}

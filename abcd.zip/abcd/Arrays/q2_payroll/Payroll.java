/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
class Payroll{
private int[] employeeID;
private int[] hours;
private double[] payRate;
private double[] wages;

Payroll(){

	employeeID=new int[] {5658845 ,4520125, 7895122, 8777541,8451277 ,1302850 ,7580489};
	hours=new int[7];
	payRate=new double[7];
	wages=new double[7];

}
public int getEmployeeID(int i) {
	if(i<7) return employeeID[i];
	return -1;
}



public void setEmployeeID(int i,int  employeeID) {
	this.employeeID[i] = employeeID;
}



public int getHours(int i) {
	if(i<7) return hours[i];
return -1;
}



public void setHours(int i,int  hours) {
	this.hours[i] = hours;
}



public double getPayRate(int i) {
	if(i<7)
	return payRate[i];
return -1;
}



public void setPayRate(int i,double payRate) {
	this.payRate[i] = payRate;
}



public double getWages(int i) {
if(i<7)	return payRate[i]*hours[i];
return -1;
}





	public static void main(String[] args)
	{
		Payroll a=new Payroll();
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<7;i++)
		{
			System.out.println("Employee: ID="+a.getEmployeeID(i));
			System.out.println("enter hours and payRate:");
			int hours=sc.nextInt();
			double payRate=sc.nextDouble();
			a.setHours(i,hours);
			a.setPayRate(i,payRate);
			System.out.println("gross wage:"+a.getWages(i));
		}
	}
}
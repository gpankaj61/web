/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.util.Scanner;
public class ques1 {
	public static void main(String [] args)
	{
		Scanner reader = new Scanner(System.in);
		int age;
		System.out.print("Enter your age:\t");
		age = reader.nextInt();
		if(age >= 18)
			System.out.println("You are eligible to vote.");
		else
			System.out.println("You are not eligible to vote.");
	}
}

/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.util.Scanner;
public class ques2 {
	public static void main (String [] args)
	{
		Scanner reader = new Scanner(System.in);
		int n;
		System.out.print("Enter the no.:\t");
		n = reader.nextInt();
		if(n%2==0)
			System.out.println("Even");
		else
			System.out.println("Odd");
	}
}

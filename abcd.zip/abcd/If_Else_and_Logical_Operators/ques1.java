/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.util.Scanner;
public class ques1 {
	public static void main(String [] args)
	{
		Scanner reader = new Scanner(System.in);
		int quiz,mid,fin;
		float per;
		System.out.print("Quiz score:\t");
		quiz = reader.nextInt();
		System.out.print("Mid-term score:\t");
		mid = reader.nextInt();
		System.out.print("Final score:\t");
		fin = reader.nextInt();
		per = ((float)(quiz + mid + fin))/3;
		if(per>=90)
			System.out.println("Your grade is A");
		else if(per>=70)
			System.out.println("Your grade is B");
		else if(per>=50)
			System.out.println("Your grade is C");
		else
			System.out.println("Your grade is F");
	}
}

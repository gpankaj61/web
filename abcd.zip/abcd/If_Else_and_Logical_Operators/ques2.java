/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.util.Scanner;
public class ques2 {
	public static void main(String [] args)
	{
		Scanner reader = new Scanner(System.in);
		int unit_price,quantity,per;
		float revenue,discount;
		System.out.print("Enter unit price:\t");
		unit_price = reader.nextInt();
		System.out.print("Enter quantity:\t\t");
		quantity = reader.nextInt();
		
		//Calculating discount
		if(quantity <= 100)
			{ discount = 0; per = 0; }
		else if(quantity <=120)
			{ discount = ((float)(unit_price * quantity))/10; per = 10; }
		else
			{ discount = ((float)(unit_price * quantity))*15/100; per = 15; }

		//Calculating revenue
		revenue = (unit_price * quantity) - discount;
		
		System.out.println("The revenue from sale:\t" +revenue+ "$");
		System.out.println("After discount:\t\t" +discount+ "$(" +per+ "%)");
	}
}

/*
 * PANKAJ KUMAR GUPTA 
 * 20144009 
 * CS-3 
 */
abstract public class Student {
	
	protected String name;
	protected String rollNo;
	protected String department;
	protected float spi;
	protected float cpi;
	protected int totalSem;
	
	abstract public void printDetails();
	
}
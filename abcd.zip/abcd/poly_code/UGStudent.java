/*
 * PANKAJ KUMAR GUPTA 
 * 20144009 
 * CS-3 
 */
public class UGStudent extends Student {
	public UGStudent (String name, String rollNo, String department) {
		this.name = name;
		this.rollNo = rollNo;
		this.department = department;
		this.cpi = 0;
		this.spi = 0;
		this.totalSem = 8;
	}
	
	@Override
	public void printDetails() {
		System.out.println("Name : " + name);
		System.out.println("Undergraduate Student");
		System.out.println("Roll No : " + rollNo);
		System.out.println("Department : " + department);
		System.out.println("CPI : " + cpi);
		System.out.println("SPI : " + spi);
	}
	
	public float getCpi() { return cpi; }
	public float getSpi() { return spi; }
	public String getName() { return name; }
	public String getDepartment() { return department; }
	public String getRollNo() { return rollNo; }
	
	public void setCpi(float cpi) { this.cpi = cpi; }
	public void setSpi(float spi) { this.spi = spi; }
	public void setName(String name) { this.name = name; }
	public void setDepartment(String department) { this.department = department; }
	public void setRollNo(String rollNo) { this.rollNo = rollNo; }
}
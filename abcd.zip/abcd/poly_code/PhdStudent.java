/*
 * PANKAJ KUMAR GUPTA 
 * 20144009 
 * CS-3 
 */
public class PhdStudent extends Student {
	
	private String ugDegree;
	private String ugInst;
	private float ugCpi;
	private String pgDegree;
	private String pgInst;
	private float pgCpi;
	private String supervisor;
	
	public PhdStudent (String name, String rollNo, String department) {
		this.name = name;
		this.rollNo = rollNo;
		this.department = department;
		this.cpi = 0;
		this.spi = 0;
		this.totalSem = 4;
	}
	
	@Override
	public void printDetails() {
		System.out.println("Name : " + name);
		System.out.println("Ph.D Student");
		System.out.println("Roll No : " + rollNo);
		System.out.println("Department : " + department);
		System.out.println("CPI : " + cpi);
		System.out.println("SPI : " + spi);
		System.out.println("UG Degree from : " + ugInst);
		System.out.println("UG CPI : " + ugCpi);
		System.out.println("PG Degree from : " + pgInst);
		System.out.println("PG CPI : " + pgCpi);
	}
	
	public float getCpi() { return cpi; }
	public float getSpi() { return spi; }
	public String getName() { return name; }
	public String getDepartment() { return department; }
	public String getRollNo() { return rollNo; }
	public float getUgCpi() { return ugCpi; }
	public String getUgDegree() { return ugDegree; }
	public String getUgInst() { return ugInst; }
	public float getPgCpi() { return pgCpi; }
	public String getPgDegree() { return pgDegree; }
	public String getPgInst() { return pgInst; }
	public String getSupervisor() { return supervisor; }
	
	
	public void setCpi(float cpi) { this.cpi = cpi; }
	public void setSpi(float spi) { this.spi = spi; }
	public void setName(String name) { this.name = name; }
	public void setDepartment(String department) { this.department = department; }
	public void setRollNo(String rollNo) { this.rollNo = rollNo; }
	public void setUgCpi(float cpi) { this.ugCpi = cpi; }
	public void setUgDegree(String degree) { this.ugDegree = degree; }
	public void setUgInst(String inst) { this.ugInst = inst; }
	public void setPgCpi(float cpi) { this.pgCpi = cpi; }
	public void setPgDegree(String degree) { this.pgDegree = degree; }
	public void setPgInst(String inst) { this.pgInst = inst; }
	public void setSupervisor(String sup) { this.supervisor = sup; }
}
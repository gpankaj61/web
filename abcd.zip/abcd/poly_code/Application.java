/*
 * PANKAJ KUMAR GUPTA 
 * 20144009 
 * CS-3 
 */
import java.io.*;

class Application {

	public static void main(String args[]){
		PhdStudent std = new PhdStudent("Anurag", "15784", "Software");
		Student s1 = new UGStudent("Pankaj", "4009", "CSE");
		std.printDetails();
		s1.printDetails();
	}
}

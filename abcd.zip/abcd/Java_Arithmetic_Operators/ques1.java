/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.util.Scanner;
public class ques1 {
	public static void main (String [] args)
	{
		Scanner reader = new Scanner(System.in);
		int a,b;
		System.out.print("Enter value a:\t");
		a = reader.nextInt();
		System.out.print("Enter value b:\t");
		b = reader.nextInt();
		System.out.println("The result of adding is " +(a+b));
		System.out.println("The result of subtracting is " +(a-b));
		System.out.println("The result of multiplying is " +(a*b));
		System.out.println("The result of dividing is " +(a/b));
	}
} 

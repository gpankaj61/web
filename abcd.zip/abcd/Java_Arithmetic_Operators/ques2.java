/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.util.*;
public class ques2 {
	public static void main (String [] args)
	{
		Random gen = new Random();
		System.out.println(gen.nextInt(6)+1);
	}
}

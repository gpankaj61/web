/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.util.*;
public class ques1 {
	public static void main (String [] args)
	{
		Scanner reader = new Scanner(System.in);
		float a,b;
		System.out.print("Enter value a:\t");
		a = reader.nextFloat();
		System.out.println("The value of a before adding is " +a);
		System.out.print("Enter value b:\t");
		b = reader.nextFloat();
		a = a + b;
		System.out.println("The value of a after adding is " +a);
	}
}

/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.util.Scanner;
public class ques2 {
	public static void main (String [] args)
	{
		Scanner reader = new Scanner(System.in);
		int dep;
		float int_rate,tax_rate, inte, tax;
		System.out.print("The amount of deposit:\t");
		dep = reader.nextInt();
		System.out.print("Yearly Interest rate:\t");
		int_rate = reader.nextFloat();
		System.out.print("Income tax rate:\t");
		tax_rate = reader.nextFloat();
		inte = (dep * int_rate)/100;
		tax = (inte * tax_rate)/100;
		System.out.println("The amount of interest earned in the year:\t" +(inte-tax));
	}
}

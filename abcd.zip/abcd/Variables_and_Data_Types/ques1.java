/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

public class ques1 {
	public static void main (String [] args)
	{
		System.out.println("Hello World");
	}
}

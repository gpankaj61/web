/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.lang.*;
import java.io.*;
public class ques4{
	public static void main(String [] args) throws Exception
	{
		String str;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Enter your name:\t");
		str = br.readLine();
		System.out.println("Hello " +str+ "!");
	}
}		

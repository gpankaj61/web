/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

public class ques3 {
	public static void main (String [] args)
	{
		int int1,int2;
		float float1;
		String string1;
		int1 = 10;
		int2 = 10;
		float1 = (float)12.5;
		string1 = "Java Programming";
		System.out.println("int1 = " +int1+ "\nint2 = " +int2+ "\nfloat1 = " +float1+ "\nstring1 = " +string1);
	}
}


/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
import java.lang.*;
class AlphabeticPhoneNumber{

	public static void print(String str)
	{
		char[] arr=str.toCharArray();
		String newString=new String();
		for(int i=0;i<str.length();i++){
			switch(str.charAt(i)){
			case 'A':
			case 'B':
			case 'C':newString+='2';break;
			case 'D':
			case 'E':
			case 'F':newString+=String.valueOf(3);break;
			case 'G':
			case 'H':
			case 'I':newString+=String.valueOf(4);break;
			case 'J':
			case 'K':
			case 'L':newString+=String.valueOf(5);break;
			case 'M':
			case 'N':
			case 'O':newString+=String.valueOf(6);break;
			case 'P':
			case 'Q':
			case 'R':
			case 'S':newString+=String.valueOf(7);break;
			case 'T':
			case 'U':
			case 'V':newString+=String.valueOf(8);break;
			case 'W':
			case 'X':
			case 'Y':
			case 'Z':newString+=String.valueOf(9);break;
			default: newString+=String.valueOf(str.charAt(i));break;
			
			}
		}
		System.out.println(newString);
	}
	public static void main(String[] args)
	{
		System.out.println("enter phone number:");
		Scanner sc=new Scanner(System.in);
		String phone=sc.nextLine();
		print(phone);

	}
}

/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
import java.lang.*;
class SumNumbersString{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String input=sc.nextLine();
		String[] arr=input.trim().split(",");
		int sum=0;
		for(String a:arr)
		{
			sum+=Integer.parseInt(a);
		}
		System.out.println("sum = "+sum);

	}
}
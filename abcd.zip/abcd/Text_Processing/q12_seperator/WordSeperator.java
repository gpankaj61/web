/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
class WordSeperator{

	public static void main(String[] args)
	{
		String inp;
		System.out.println("enter string:");
		Scanner sc=new Scanner(System.in);
		inp=sc.nextLine();
		char[] arr=inp.toCharArray();
		System.out.print(inp.charAt(0));
		for(int i=1;i<inp.length();i++){
			char c=inp.charAt(i);
			if(c>='A'&&c<='Z')
				System.out.print(" ");

			System.out.print(Character.toLowerCase(c));

		}
		System.out.println();
	}
}

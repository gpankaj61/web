/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
class Telemarketing{

	public static void main(String[] args)
	{
		String[] name = {"Harrison, Rose","James, Jean", "Smith, William","Smith, Brad"};
		String[] num={"555-2234","555-9096","555-1785","555-9224"};
		System.out.println("enter name or initials:");
		Scanner sc=new Scanner(System.in);
		String inp=sc.nextLine();
		for(int i=0;i<4;i++){
		int ind=name[i].indexOf(inp);
		if(ind!=-1)
			System.out.println(name[i]+"\t"+num[i]);

		}




	}
}
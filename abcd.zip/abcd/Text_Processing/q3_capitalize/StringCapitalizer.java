/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
import java.lang.*;
class StringCapitalizer{

	public static void main(String[] args)
	{
		String input;
		Scanner sc=new Scanner(System.in);
		input=sc.nextLine();
		char arr[]=input.toCharArray();
		boolean flag=true;
		for(char c:arr)
		{
			if(flag==true&&(c<='z'&&c>='a'))
			{
			System.out.print(Character.toUpperCase(c));
			flag=false;
			continue;
			}
			if(c=='.')
			flag=true;
			System.out.print(c);		
		}
		System.out.println();
	}
}
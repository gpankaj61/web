/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
import java.lang.*;
class MiscellStringOps{
	public static int wordCount(String str)
	{
		StringTokenizer st = new StringTokenizer(str);
		return st.countTokens();	
	}
	public static String arrayToString(char[] arr){
		return String.valueOf(arr);
	}
	public static char mostFrequent(String str)
	{
		char arr[]=str.toCharArray();
		int[] count=new int[26];
		for(char c:arr)
			if(Character.toLowerCase(c)>='a'&&Character.toLowerCase(c)<='z')
				count[Character.toLowerCase(c)-97]++;
		int maxi=0,in=0;
		for(int i=0;i<26;++i)
			if(count[i]>maxi)
				{
					maxi=count[i];
					in=i;
				}
		int a='a'+in;
		char ans=(char)a;
		return ans;
	}	
	public static String replaceSubstring(String string,String find,String replace){
		if(string.equals(find))
			return replace;

		StringBuffer str=new StringBuffer(string);
		int index=str.indexOf(find);
		while(index!=-1){
			str.replace(index,index+find.length(),replace);
			index=str.indexOf(find);
		}
		return str.toString();
	}


	public static void main(String[] args)
	{	
		String inp="the dog jumped over the fence";
		System.out.println("string:"+inp);
		System.out.println("word count: "+wordCount(inp));
        	System.out.println("most Frequent char: "+mostFrequent(inp));
        	System.out.println("the replaced by that:new String  :");
        	inp=inp.replace("the","that");
        	System.out.println(inp);
        	System.out.println("string:"+arrayToString(inp.toCharArray()));

	}
}

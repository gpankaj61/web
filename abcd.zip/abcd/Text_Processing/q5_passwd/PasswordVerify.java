/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
import java.lang.*;
class PasswordVerify{

	public static void main(String[] args)
	{
		String input;
		System.out.println("enter password:");
		Scanner sc=new Scanner(System.in);
		input=sc.nextLine();
		boolean flag=false;
		if(input.length()>=6)
		{
			boolean f1=false,f2=false,f3=false;
			char[] arr=input.toCharArray();
			for(char c:arr)
			{
				if(c<='z'&&c>='a')
					f1=true;
				if(c<='Z'&&c>='A')
					f2=true;
				if(c<='9'&&c>='0')
					f3=true;
				
				
			}
			if(f1==true&&f2==true&&f3==true)
				flag=true;
		}
		if(flag==true)
			System.out.println("Valid");
		else
			System.out.println("Invalid");

	}
}
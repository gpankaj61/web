/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
class SumDigitsString{

	public static void main(String[] args)
	{
		
		Scanner sc=new Scanner(System.in);
		String inp=sc.nextLine();
		char[] arr=inp.toCharArray();
		char maxi=arr[0],mini=arr[0];
		int sum=0;
		for(char a:arr)
		{
			if(a>maxi)
				maxi=a;
			if(a<mini)
				mini=a;
			sum+=a-'0';
		}
		System.out.println("Max: "+maxi+" Min: "+mini+" sum: "+sum);
	}
}
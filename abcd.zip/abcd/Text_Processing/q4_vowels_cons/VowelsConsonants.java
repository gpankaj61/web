/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
import java.lang.*;
class VowelsConsonants{

	public static void vowels(String input)
	{
		int count=0;
		char arr[]=input.toCharArray();
		for(char c:arr)
		{
			if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
			{
			count++;	
			}
		}
		System.out.println("vowels count="+count);
	}

 public static void consonants(String input)
	{
		int count=0;
		char arr[]=input.toCharArray();
		for(char c:arr)
		{
			if(c<='z'&&c>='a'&&!(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'))
			{
			count++;	
			}
		}
		System.out.println("consonants count="+count);
	}
	
	public static void main(String[] args)
	{
		String input;
		Scanner sc=new Scanner(System.in);
		System.out.print("enter a string:");
		input=sc.nextLine();
		while(true)
		{
		System.out.println("Choose option:\na. Count the number of vowels in the string\nb, Count the number of consonants in the string\nC Count both the vowels and consonants in the string\nd. Enter another string\ne. Exit the program");
		char op=sc.next().charAt(0);
		switch(op)
		{
			case 'a': vowels(input);break;
			case 'b': consonants(input);break;
			case 'c': vowels(input);consonants(input);break;
			case 'd': sc.nextLine(); System.out.print("enter a string:");
		input=sc.nextLine();break;
			case 'e': return ;
		}
	}
	
	}
}
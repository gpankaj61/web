/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
class PigLatin{
	public static void main(String[] args)
	{
		System.out.print("enter English sentence:");
		Scanner sc=new Scanner(System.in);
		String eng=sc.nextLine(),latin=new String();
		String[] arr=eng.split(" ");
		for(String a:arr){
			a=a.substring(1)+String.valueOf(a.charAt(0))+"AY ";
			latin+=a;
		}
		System.out.println("English:"+eng);
		System.out.println("Latin:"+latin);	
	}
}

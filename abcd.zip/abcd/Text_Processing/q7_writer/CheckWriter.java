/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
import java.lang.*;
class CheckWriter{
public static String toWords(double am)
{

    String[] one_19 = {"", "one", "two", "three", "four",
        "five", "six", "seven", "eight", "nine", "ten", 
        "eleven", "twelve",
        "thirteen", "fourteen", "fifteen", "sixteen", "seventeen",
        "eighteen", "nineteen"};

    String[] twenty_90 = {"","","twenty","thirty","forty",
        "fifty", "sixty", "seventy", "eighty", "ninety"};


    int amount=(int)am;
    int a = amount/1000;
    int b = (amount%1000)/100;
    int c =  (amount%100)/10;
    int d = amount%10;
    int cents = (new Double(am*100).intValue())%100;
	String amount_string=new String();

    if (a >= 1)
        amount_string = one_19[a] + " thousand " ;
    if(b>=1)
    	amount_string+=one_19[b] + " hundred " ;
    if(c==1)
    	amount_string+= one_19[c*10+d];
    else
    	amount_string+=twenty_90[c]+" " + one_19[d] ;
    if(cents>0)
    {
    	amount_string+=" and ";
    	int x=cents/10;
    	int y=cents%10;
    	if(x==1)
    		amount_string+= one_19[x*10+y];
    	else
    		amount_string+=twenty_90[x]+" " + one_19[y];
    	amount_string+=" cents";


    }
    return amount_string;

}

	public static void main(String[] args)
	{
System.out.println("enter date, payee name, amount of cheque:");
Scanner sc=new Scanner(System.in);
String date=sc.nextLine();
String name=sc.nextLine();
double amount=sc.nextDouble();
System.out.println("\t\tDate: "+date);
System.out.println();
System.out.println("Pay to the Order of: "+name+"\t\t$"+amount);
System.out.println();
System.out.println(toWords(amount));



	}
}

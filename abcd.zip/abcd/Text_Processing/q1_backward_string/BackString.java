/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
public class BackString{
	public static void  displayRev(String inp){
		char[] conv=inp.toCharArray();
		
		for(int i=0,j=inp.length()-1;i<j;i++,j--)
			{
				char temp=conv[i];
				conv[i]=conv[j];
				conv[j]=temp;

			}	
		for(char c:conv)
			System.out.print(c);
		System.out.println();

	}

	public static void main(String[] args)
	{
		String input;
		Scanner sc=new Scanner(System.in);
		input=sc.nextLine();
//		System.out.println(input);
		displayRev(input);

	}
}
/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
import java.lang.*;
class WordCounter{

	public static void main(String[] args)
	{
		String input;
		Scanner sc=new Scanner(System.in);
		input=sc.nextLine();
		System.out.println("number of words="+input.trim().split("\\s+").length);
		
	}
}
/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.util.Scanner;
public class ques1 {
	public static void main(String [] args)
	{
		Scanner reader = new Scanner(System.in);
		char ch;
		ch = reader.next().charAt(0);
		
		//Detecting key pressed
		switch(ch)
		{
			case '0':
				System.out.println("Key 0 is pressed");
				break;			
			case '1':
				System.out.println("Key 1 is pressed");
				break;
			case '2':
				System.out.println("Key 2 is pressed");
				break;
			case '3':
				System.out.println("Key 3 is pressed");
				break;
			case '4':
				System.out.println("Key 4 is pressed");
				break;
			case '5':
				System.out.println("Key 5 is pressed");
				break;
			case '6':
				System.out.println("Key 6 is pressed");
				break;
			case '7':
				System.out.println("Key 7 is pressed");
				break;
			case '8':
				System.out.println("Key 8 is pressed");
				break;
			case '9':
				System.out.println("Key 9 is pressed");
				break;
			default:
				System.out.println("Not Allowed");
		}
	}
}

/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.util.Scanner;
public class two {
	public static void main(String [] args)
	{
		Scanner reader = new Scanner(System.in);
		System.out.println("What is the correct way to declare a variable to store an integer value in Java?");
		System.out.println("a. int 1x=10;");
		System.out.println("b. int x=10;");
		System.out.println("c. float x=10.0f;");
		System.out.println("d. string x=\"10\";");
		System.out.print("Enter your choice:\t");
		char ch;
		ch = reader.next().charAt(0);

		//Checking the answer
		switch(ch)
		{
			case 'b':
				System.out.println("Congratulations!");
				break;
			default:
				System.out.println("Invalid Choice");
		}
	}
}

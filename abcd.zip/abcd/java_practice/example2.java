import java.awt.*;
import java.awt.event.*;
class mywin extends Frame implements ActionListener
{	
	Label l1,l2,l3;
	TextField t1,t2,t3;
	Button b1;
	public mywin()
	{
		setTitle("Calculation");
		setLayout(null);
		l1=new Label("First Number  ");
		l2=new Label("Second Number");
		t1=new TextField(20);
		t2=new TextField(20);
		l3=new Label("Sum");
		t3=new TextField(20);
		b1=new Button("OK");
		l1.setBounds(10,40,150,20);
		t1.setBounds(160,40,120,20);
		l2.setBounds(10,70,150,20);
		t2.setBounds(160,70,120,20);
		l3.setBounds(10,100,150,20);
		t3.setBounds(160,100,120,20);
		b1.setBounds(160,130,120,20);
		add(l1);
		add(t1);
		add(l2);
		add(t2);
		add(l3);
		add(t3);
		add(b1);
		b1.addActionListener(this);
		setSize(400,250);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent e)
	{
		int a,b,c;
		a=Integer.parseInt(t1.getText());		
		b=Integer.parseInt(t2.getText());
		c=a+b;
		t3.setText(Integer.toString(c));
	}

}
class example2 
{
	public static void main(String args[])
	{
		mywin obj=new mywin();
	}
	
}

import java.awt.*;
import java.awt.Event.*;

public class pankaj extends Frame implements ActionListener{
	TextField tf;
	pankaj(){
		tf = new TextField();
		tf.setText("THis is a text field");
		setTitle("Hello pankaj");
		setLayout(null);
		setVisible(true);
		setSize(300,300);
		Button b1 = new Button("Jadoo");
		b1.setBounds(30,30,60,60);
		tf.setBounds(300,300,300,300);
		add(b1);
		b1.addActionListener(this);
		add(tf);

	}

	public void actionPerformed(ActionEvent e){
		tf.setText("changed");
	}
	public static void main(String args[]){
		pankaj p = new pankaj();

	}

}
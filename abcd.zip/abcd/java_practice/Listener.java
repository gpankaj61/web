import java.io.*;
import java.awt.*;
import java.awt.event.*;

class Listener extends Frame implements ActionListener{
	TextField tf;
	Listener(){
		setTitle("Hello");
		setLayout(null);
		tf = new TextField();
		tf.setText("Default text");
		Button b = new Button("Submit");
		setSize(500,500);				//layout_size
		b.setBounds(100,100,100,50);	//size_of_botton
		tf.setBounds(200,200,100,50);	//size_of_textfield
		b.addActionListener(this);
		add(b);							//adding_button
		add(tf);
		setVisible(true);
		//setCloseAble(true);
	}
	public void actionPerformed(ActionEvent e){
		System.out.println("inside button");
		tf.setText("text changed");
		setBackground(Color.blue);

	}
	public static void main(String args[]){
		Listener l = new Listener();
	}
}
import java.awt.*;
import java.awt.event.*;

class win extends Frame implements ActionListener{
	Button b1,b2,b3;
	public win(){
		setTitle("Example:1");
		setLayout(new FlowLayout());
		b1 = new Button("Red");
		b2 = new Button("Blue");
		b3 = new Button("Green");
		add(b1);
		add(b2);
		add(b3);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		setSize(400,200);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent e){
		if (e.getSource()==b1) {
			setBackground(Color.red);
		}
		if (e.getSource()==b2) {
			setBackground(Color.blue);
		}
		if (e.getSource()==b3) {
			setBackground(Color.green);
		}
	}
}
class test{
	public static void main(String[] args) {
		win obj = new win();
	}
}
import java.awt.*;
import java.applet.*;
public class clock extends Applet{
	int sx=0,sy=0,mx=0,my=0,hx=0,hy=0;
	int s=0,m=0,h=0;
	int cx = 200, cy=200, sr=100, mr=75,hr=50;
	double sangle = 0, mangle = 0, hangle = 0;
	public void paint(Graphics g){

		sy = cy - (int)(Math.sin(sangle)*sr);
		sx = cx - (int)(Math.cos(sangle)*sr);

		my = cy - (int)(Math.sin(mangle)*mr);
		mx = cx - (int)(Math.cos(mangle)*mr);

		hy = cy - (int)(Math.sin(hangle)*hr);
		hx = cx - (int)(Math.cos(hangle)*hr);
		g.drawOval(cx-100,cy-100,2*sr,2*sr);
		
		g.drawLine(cx,cy,sx,sy);
		g.drawLine(cx,cy,mx,my);
		g.drawLine(cx,cy,hx,hy);
		try{
			Thread.sleep(1000);
		}
		catch(Exception e){

		}
		sangle+=Math.PI/30;
		mangle+=Math.PI/1800;
		hangle+=Math.PI/108000;
		repaint();
	}
}
import java.awt.*;
import java.awt.event.*;
class abc extends Frame implements ActionListener{
	Button b1,b2;
	public abc(){
		setTitle("Thullu");
		setLayout(new FlowLayout());
		b1 = new Button("Color");
		b2 = new Button("Exit");
		add(b1);
		add(b2);
		b1.addActionListener(this);
		b2.addActionListener(this);
		setSize(400,400);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent e){
		if (e.getSource()==b1) {
			setBackground(Color.green);
		}
		if (e.getSource()==b2) {
			System.exit(0);
		}
	}
}
class btn{
	public static void main(String args[]){
		abc obj = new abc();
	}
}
import java.awt.*;
class win extends Frame
{
	Label l1,l2,l3;
	TextField t1,t2;
	Button b1;
	GridLayout grid;
	public win()
	{
		setTitle("My First Window");
		setLayout(new GridLayout(3,2));
		l1=new Label("Enter User Name ");
		l2=new Label("Enter Password");
		//l3=new Label("");
		t1=new TextField(20);
		t2=new TextField(20);
		t2.setEchoChar('*');
		b1=new Button("Login");
		add(l1);
		add(t1);
		add(l2);
		add(t2);
		//add(l3);
		add(b1);
		setSize(400,150);
		setVisible(true);
	}
}
class twist
{
	public static void main(String args[])
	{
		win obj=new win();
	}
}

import java.awt.*;
import java.awt.event.*;
class Calculator extends Frame implements ActionListener{
	Button b1;
	Label l1,l2,l3;
	TextField t1,t2,t3;
	public Calculator(){
		setTitle("Chotawala Calculator");
		setLayout(new FlowLayout());
		b1 = new Button("Calculate");
		t1 = new TextField(20);
		t2 = new TextField(20);
		t3 = new TextField(20);
		l1 = new Label("First Number");
		l2 = new Label("Second Number");
		l3 = new Label("Result");
		add(l1);
		add(t1);
		add(l2);
		add(t2);
		add(l3);
		add(t3);
		add(b1);
		b1.addActionListener(this);
		setSize(400,200);
		setVisible(true);

	}
	public void actionPerformed(ActionEvent e){
		if (e.getSource()==b1) {
			int a,b,c;
			a = Integer.parseInt(t1.getText());
			b = Integer.parseInt(t2.getText());
			c = a + b;
			t3.setText(Integer.toString(c));
		}
	}
}
class cal{
	public static void main(String args[]){
		Calculator obj =new Calculator();
	}
}
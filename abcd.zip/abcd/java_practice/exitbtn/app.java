import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

public class app extends Applet implements ActionListener,TextListener{
   private int x=50;
   private int y=50;
   private int play = 0;
   private Button b1;
   private Button b2;
   TextField tf;
   private int speed=400;
   public void paint(Graphics g){
   	g.drawOval(x,y,100,100);
      if(play == 1)
         move();
   }
   public void move(){
      x+=10;      
      x=x%500;
      y=y%500;
      try{
         Thread.sleep(500-speed);
      }
      catch (Exception e){
            System.out.println(e);
         }
      repaint();  
   }

   public void init(){

      b1 = new Button("Play");
      b1.setBounds(50,20,50,50);
      add(b1);
      b1.addActionListener(this);

      b2 = new Button("Pause");
      b2.setBounds(100,20,50,50);
      add(b2);
      b2.addActionListener(this);

      tf = new TextField("",10);
      tf.setBounds(10,20,100,50);
      tf.addTextListener(this);
      add(tf);
   }

   public void actionPerformed(ActionEvent e){
      if(e.getSource() == b1){
         play = 1;
         repaint();
      }
      else{
         play = 0;
      }     
   }

   public void textValueChanged(TextEvent e) {
         speed = Integer.parseInt(tf.getText());
         repaint();              
      }   
}
import java.awt.*;
import java.awt.event.*;
class btn extends Frame implements ActionListener{
	Button b1;
	public btn (){
		setTitle("Btn Exit");
		setLayout(new FlowLayout());
		b1 = new Button("Click");
		add(b1);
		//setBounds(200,200,100,50);
		b1.addActionListener(this);
		setSize(400,400);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent e){
		if (e.getSource()==b1) {
			System.exit(0);
		}
	}
} 
class exitbtn{
	public static void main(String[] args) {
		btn obj = new btn();
	}
}
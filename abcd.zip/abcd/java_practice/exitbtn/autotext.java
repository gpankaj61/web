import java.awt.*;
import java.awt.event.*;
class Auto extends Frame implements TextListener, ActionListener{
	TextField t1,t2;
	Label l1,l2;
	Button b1;
	public Auto(){
		setTitle("Auto_Configure");
		setLayout(new GridLayout(4,2));
		t1 = new TextField(20);
		t2 = new TextField(20);
		l1 = new Label("Amount");
		l2 = new Label("Tax");
		b1 = new Button("Exit");
		add(l1);
		add(t1);
		add(l2);
		add(t2);
		add(b1);
		t1.addTextListener(this);
		b1.addActionListener(this);
		setSize(400,200);
		setVisible(true);

	}
	public void actionPerformed(ActionEvent e){
		if (e.getSource()==b1) {
			System.exit(0);
		}
	}
	public void textValueChanged(TextEvent e){
		if (e.getSource()==t1) {
			int amt;
			float tax;			
			amt = Integer.parseInt(t1.getText());
			tax = (float)amt*40/100;
			t2.setText(Float.toString(tax));
		}
	}
}
class autotext{
	public static void main(String[] args) {
		Auto obj = new Auto();
	}
}
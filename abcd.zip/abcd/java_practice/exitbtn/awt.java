import java.applet.*;
import java.awt.*;
public class awt extends Applet
{
	Label l1,l2;
	Choice c1;
	List li1;
	
	public void init()
	{
		l1=new Label("Select Name");
		l2=new Label("Select City");
		c1=new Choice();
		li1=new List(3,true);
		c1.add("Ravi");
		c1.add("Vipin");
		c1.add("Janmejay");
		c1.add("Shashank");
		c1.add("Dev");
		li1.add("Allahabad");
		li1.add("Delhi");
		li1.add("Kanpur");
		li1.add("Lucknow");
		add(l1);
		add(c1);
		add(l2);
		add(li1);
	}
}
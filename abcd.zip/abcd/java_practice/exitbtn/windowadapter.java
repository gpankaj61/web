import java.awt.*;
import java.awt.event.*;
class win extends Frame 
{
	public win()
	{
		setTitle("Event Handling Window");
		setLayout(new FlowLayout());
		setSize(400,150);
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.out.println("RP");
				System.exit(0);
			}
		});
		setVisible(true);
	}
	
}
class windowadapter
{
	public static void main(String args[])
	{
		win obj=new win();
	}
}

import java.applet.Applet; 
import java.awt.*; 
public class sum extends Applet 
{    
TextField t1,t2; 
      public void init()  
        { 
       t1=new TextField(8); 
       t2=new TextField(8); 
       add(t1); 
       add(t2); 
       t1.setText("0");  
       t2.setText("0");        
       } 
public void paint (Graphics g) 
{        int a,b; 
        a=Integer.parseInt(t1.getText()); 
        b=Integer.parseInt(t2.getText()); 
        int c=a+b; 
        String s=Integer.toString(c); 
        g.drawString("the sum is",20,30); 
        g.drawString(s,50,50); 
}} 
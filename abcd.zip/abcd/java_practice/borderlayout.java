import java.awt.*;
class win extends Frame
{
	Label l1,l2;
	public win()
	{
		setTitle("My First Window");
		setLayout(new BorderLayout());
		l1=new Label("United College",Label.CENTER);
		l1.setBackground(Color.pink);
		l2=new Label("Naini",Label.RIGHT);
		add(l1,"North");
		add(l2,"West");
		setSize(400,150);
		setVisible(true);
	}
}
class borderlayout
{
	public static void main(String args[])
	{
		win obj=new win();
	}
}


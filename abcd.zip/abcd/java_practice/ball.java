import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;

public class ball extends Applet implements ActionListener, TextListener{
	private int x = 100;
	private int y = 100;
	Button b1,b2;
	TextField t1;
	private int play = 0;
	private int Speed = 100;
	public void paint(Graphics g){
		g.drawOval(x,y,50,50);
		if (play==1) {
			move();
		}
	}
	public void move(){
		x+=4;
		x%=500;
		y%=500;
		try{
			Thread.sleep(500-Speed);
		}
		catch (Exception e) {
			System.out.println("LOL");
		}
		repaint();
	}
	public void init(){
		//setTitle("Dekh Ball Ghumraha Hai");
		//setLayout(null);
		b1 = new Button("Play");
		setBounds(10,50,50,50);
		add(b1);
		b1.addActionListener(this);

		b2 = new Button("Pause");
		setBounds(60,50,50,50);
		add(b2);
		b2.addActionListener(this);

		t1 = new TextField(20);
		setBounds(70,50,50,50);
		add(t1);
		t1.addTextListener(this);

	}

	public void actionPerformed(ActionEvent e){
		if (e.getSource()==b1) {
			play = 1;
			repaint();
		}
		if (e.getSource()==b2) {
			play = 0;
		}
	}

	public void textValueChanged(TextEvent e){
		Speed = Integer.parseInt(t1.getText());
		repaint();
	}
}
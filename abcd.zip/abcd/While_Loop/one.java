/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.util.Scanner;
public class one {
	public static void main (String [] args)
	{
		Scanner reader = new Scanner(System.in);
		char ch;

		//Printing the question		
		System.out.println("What is the command keyword to exit a loop in Java?");
		System.out.println("a. int");
		System.out.println("b. continue");
		System.out.println("c. break");
		System.out.println("d. exit");

		//Looping
		while(true)
		{
			System.out.print("Enter your choice:\t");
			ch = reader.next().charAt(0);
			if(ch=='c')
			{
				System.out.println("Congratulations!");
				break;
			}
			else
			{
				System.out.println("Incorrect!");
				System.out.print("Again? press y to continue:\t");
				ch = reader.next().charAt(0);
				if(ch != 'y')
					break;
			}
		}
	}
}
	
				

/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

public class two {
	public static void main (String [] args)
	{
		char ch=1;
		while(ch<=122)
		{
			System.out.print(ch+ "\t");
			if(ch%10==0)
				System.out.println();
			ch++;
		}				
		
	}
}

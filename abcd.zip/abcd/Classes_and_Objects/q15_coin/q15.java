/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

public class q15 {
     public static void main(String[] args) {
        // TODO code application logic here
        int i;
        coin c=new coin();
        
        for(i=0;i<20;i++){
            System.out.println("Status :"+c.getSideUp());
            c.toss();
        }
          System.out.println("Status :"+c.getSideUp());

        
    }
    
}

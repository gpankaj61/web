/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.util.Random;
public class coin {
    String sideUp;
    Random gen=new Random();
   coin(){
       //sideUp=new String();
      int i=(gen.nextInt(2));
                //System.out.println("Rand "+i);

      if(i==0)
      {
          sideUp="heads";
      }
      else
          sideUp="tails";
   }
   
   void toss(){
        int i=(gen.nextInt(2));
      if(i==0)
      {
         sideUp="heads";
      }
      else
           sideUp="tails";
   }
   
   
   String getSideUp(){
       return sideUp;
   }
   
  }
    


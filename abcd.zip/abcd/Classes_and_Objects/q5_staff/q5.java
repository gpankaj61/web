/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;

class staff
{
	int code;
	String name;
	public void setname(String nm)
	{
		name=nm;
	}
	public void setcode(int c)
	{
		code=c;
	}
	public String getname()
	{
		return this.name;
	}
	public int getcode()
	{
		return this.code;
	}
}

class teacher extends staff
{
	String publ;
	String subj;
	public void setpub(String nm)
	{
		publ=nm;
	}
	public void setsub(String nm)
	{
		subj=nm;
	}
	public String getpub()
	{
		return this.publ;
	}
	public String getsub()
	{
		return this.subj;
	}
}

class typist extends staff
{
	int speed;
	public void setspeed(int s)
	{
		speed=s;
	}
	public int getspeed()
	{
		return this.speed;
	}
}

class officer extends staff
{
	char grade;
	public void setgrade(char g)
	{
		grade = g;
	}
	public char getgrade()
	{
		return this.grade;
	}
}

class casual extends typist
{
	int dailywage;
	public void setdailywage(int d)
	{
		dailywage=d;
	}
	public int getdailywage()
	{
		return this.dailywage;
	}
}

class regular extends typist
{

}


class q5
{

	public static void main(String args[])
	{
	
		casual s = new casual();
		s.setname("XYX ABCD");
		s.setcode(1234);
		s.setspeed(23);
		s.setdailywage(1000);
		System.out.println("\n The Details of the casual Typist is : \n ");
		System.out.println("\n Name : "+s.getname());
		System.out.println("\n Code : "+s.getcode());
		System.out.println("\n Speed : "+s.getspeed());
		System.out.println("\n Daily Wage : "+s.getdailywage());				
			
		
	}
}

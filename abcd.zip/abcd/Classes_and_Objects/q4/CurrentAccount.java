/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
package account;
public class CurrentAccount extends Account {

    double minBal;
    double penalty;

    CurrentAccount(String cname, long accno, int type, double rate, double minBal, double penalty) {

        this.cname=cname;
        this.accno=accno;
        this.type=type;
        this.minBal=minBal;
        this.penalty=penalty;


    }
    
    
    
    
    @Override
    void deposit(double amount) {
        bal+=amount;
    }

    @Override
    boolean permitWithdrawl(double amount) {
        return amount<bal;
    }
    
    
    void check()
    {
        if(bal<minBal)
            bal-=penalty;
        
    }
    
}

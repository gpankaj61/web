/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.util.*;
class Q2{
String depositor;
long acc_no;
String toa;
double bal;
 Q2(String depositor,long acc_no,String toa,double bal){
 	this.depositor=depositor;
 	this.acc_no=acc_no;
 	this.toa=toa;
 	this.bal=bal;
}
void deposit(double am){
	bal+=am;
}
void withdraw(double am){
	bal-=am;
}
void display(){
	System.out.println("\nAccount Holder:"+depositor+"\nAcc No:"+acc_no+"\nType of Account:"+toa+"\nBalance:"+bal);
}
public static void main(String args[]){
	Scanner in=new Scanner(System.in);
	String name;
	long accno;
	String tyoa;
	double balance;
	System.out.println("Enter name:");
	name=in.next();
	System.out.println("Enter AccountNo:");
	accno=in.nextLong();
	System.out.println("Enter Type of account(saving/current):");
	tyoa=in.next();
	System.out.println("Enter Balance:");
	balance=in.nextDouble();
	Q2 b=new Q2(name,accno,tyoa,balance);
	double am;
	System.out.println("Enter Amount to be deposited");
	am=in.nextDouble();
	b.deposit(am);
	System.out.println("Enter Amount to be withdrawn");
	am=in.nextDouble();
	b.withdraw(am);
	System.out.println("\n\nDetails:::");
	b.display();
}
}
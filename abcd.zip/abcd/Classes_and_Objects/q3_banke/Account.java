/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
//package account;
abstract public class Account {

    String cname;
    long accno;
    int type;
    double bal;
    double rate;    
    abstract void deposit(double amount);    
    void display()
    {
        System.out.println("Balance is "+bal);
    }
    
    void computeInterest(double t)
    {
        double intr; 
        intr = Math.pow((1+rate/100),t)*bal;
        deposit(intr);
    }
    abstract boolean permitWithdrawl(double amount);
}
    
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
//package account;
public class SavingAccount extends Account {    
    void init(String cname,long accno,int type,double rate){
        this.cname=cname;
        this.accno=accno;
        this.type=type;
        this.rate=rate;
    }  
   @Override
   void deposit(double amount)
   {
       bal+=amount;
   }

    @Override
    boolean permitWithdrawl(double amount) {
        if(bal>amount)
            return true;
        return false;
    }
    
    
    
}

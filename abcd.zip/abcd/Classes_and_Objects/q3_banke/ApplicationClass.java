/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
//package account;
import java.util.Scanner;
public class ApplicationClass {
    
    
    public static void main(String args[])
    {
        //Account ac;
        System.out.println("Enter \n1.Saving Account \n2.Current Account\n");
        
        int type;
        String name;
        long accno;
        double am;
        double rate;
        Scanner in=new Scanner(System.in);
        type=in.nextInt();
        if(type==1){
           SavingAccount ac=new SavingAccount();
            System.out.println("Enter account number and Name and Rate");
           accno=in.nextLong();
           name=in.next();
           rate=in.nextDouble();
           
           ac.init(name,accno,type,rate);
          
         System.out.println("Enter \n1.Deposit \n2.Display Bal\n3.Compute Interest\n"
                 + "4.Check Permissions to withdraw\n-1 to exit");
         
         int choice;
         choice=in.nextInt();
         while(choice!=-1){
         switch(choice)
         {
             case 1: System.out.println("Enter amount");
                        am=in.nextDouble();
                        ac.deposit(am);
                        break;
             case 2:   ac.display();
                        break;
                        
             case 3:    
                        System.out.println("Enter time");
                        double time=in.nextDouble();
                        ac.computeInterest(time);
                        break;
             case 4:   
                        am=in.nextDouble();
                        if(ac.permitWithdrawl(am))
                               System.out.println("Permitted"); 
                        else
                               System.out.println("Not Permitted"); 

                        break;
          
         }


         }
        }
        else if(type==2){
            CurrentAccount ac=new CurrentAccount();
            System.out.println("Enter account number and Name");
           accno=in.nextLong();
           name=in.next();
           rate=in.nextDouble();
           double minBal;
           double penalty;
           minBal=in.nextDouble();
           penalty=in.nextDouble();
           ac.init(name,accno,type,rate,minBal,penalty);
           
          
         System.out.println("Enter \n1.Deposit \n2.Display Bal\n3.Compute Interest\n"
                 + "4.Check Permissions to withdraw\n5.Check for Penalty\n-1 to exit");
         
         int choice;
         choice=in.nextInt();
         
         switch(choice)
         {
             case 1: System.out.println("Enter amount");
                        am=in.nextDouble();
                        ac.deposit(am);
                        
                        break;
             case 2:   ac.display();
                        break;
                        
             case 3:    
                        System.out.println("Enter time");
                        double time=in.nextDouble();
                        ac.computeInterest(time);
                        break;
             case 4:   
                        am=in.nextDouble();
                        if(ac.permitWithdrawl(am))
                               System.out.println("Permitted"); 
                        else
                               System.out.println("Not Permitted"); 

                        break;
             case 5:    ac.check();
                            break;
         }


            
            
            
            
            
        }
        

        
        
    }
    
}

/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
package student;
import java.util.Scanner;
public class ApplicationClass {
    
    public static void main(String args[])
    {
        //make three objects
        Student stu[]=new Student[3];
        
        Scanner in=new Scanner(System.in);
        int i;
        for(i=0;i<3;i++)
            stu[i]=new Student();
        for(i=0;i<3;i++){
            String name,address,phone;
            int age;
            System.out.println("Enter name,address,phone,age");
            name=in.nextLine();
            address=in.nextLine();
            phone=in.nextLine();
            age=in.nextInt();
            
            stu[i].setName(name);
            stu[i].setAddress(address);
            stu[i].setAge(age);
            stu[i].setPhone(phone);
            
            
            System.out.println("Student info:::\n name:"+stu[i].getName()+"\nAddress:"+
                    stu[i].getAddress()+"\nPhone:"+stu[i].getPhone()+"\nAge:"+stu[i].getPhone());
            
            
            
            
            
        }
        
        
    }
    
    
}

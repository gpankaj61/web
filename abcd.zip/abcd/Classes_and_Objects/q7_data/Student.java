/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
package student;
public class Student {
   String name;
   String address;
   int age;
   String phone;
   
   
   
   String getName(){
       return name;
   }
   
   
   String getAddress(){
       return address;
   }
   
   int getAge()
   {
       return age;
   }
   
   String getPhone(){
       return phone;
   }
   
   void setName(String name){
       this.name=name;
   }
   
   void setAddress(String address){
       this.address=address;
   }
   
   void setAge(int age){
       this.age=age;
   }
   
   void setPhone(String phone)
   {
       this.phone=phone;
   }
   
   
    
}

/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
package interest;
public class Interest {
	double bal;
    double rate;
    
    Interest(double bal,double rate){
        this.bal=bal;
        this.rate=rate;
        
    }
    
    void deposit(double am){
        bal+=am;
    }
    
    void withdraw(double am){
        if(am<=bal)
            bal-=am;
        else
            System.out.println("Not Available");
    }
    
    double getBal(){
        return bal;
    }
    
    void DepoIntr(){
        double intr=bal*rate/100;
        bal+=intr;
    }
    
    double getIntr(){
         double intr=bal*rate/100;
        bal+=intr;
        return intr;
    }
    
}

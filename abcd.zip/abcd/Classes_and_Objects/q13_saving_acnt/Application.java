/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
package interest;
import java.util.Scanner;
public class Application {
     public static void main(String[] args) {
        // TODO code application logic here
        double bal;
        double rate;
        int nm;
        double totdeposit=0,totwithdraw=0,totintr=0;
        Scanner in=new Scanner(System.in);
        System.out.println("Enter Initial Balance\t Rate \t No of months");
        bal=in.nextDouble();
        rate=in.nextDouble();
        nm=in.nextInt();
        
        int i=nm;
        Interest ob=new Interest(bal,rate);
        while(i>0){
            ob.DepoIntr();
            System.out.println("Deposit Amount");
            double am;
                    am=in.nextDouble();
                     ob.deposit(am);

            totdeposit+=am;
            totintr+=ob.getIntr();
            System.out.println("Withdraw Amount");
            
                    am=in.nextDouble();
                     ob.deposit(am);

            totwithdraw+=am;
            
            
            
            i--;
        }
        
        
        System.out.println("Total Deposit:"+totdeposit+"\nTotal Withdraw :"+
                totwithdraw+"\nTotal Interest :"+totintr+"\nBalance :"+ob.getBal());
        
        
        
    }
    
}

/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
package bank;
public class Bank {
    double bal;
    int nc;
   Bank(double bal,int nc){
       this.bal=bal;
       this.nc=nc;
   }
   
   double getBalance(){
       return bal;
   }
   
   
   double calFees(){
       int i;
       double charges=0;
       double charge=0;
       if(nc<20){
           i=nc;
           
           while(i>0){
               charge=0;
               charge+=10;
               if(bal<400){
                   charge+=15;
               }
               charge+=0.1;
               bal-=charge;
               charges+=charge;
               i--;
           }
           
       }
       else if(nc<39){
            i=nc;
           
           while(i>0){
               charge=0;
               charge+=10;
               if(bal<400){
                   charge+=15;
               }
               charge+=0.08;
               bal-=charge;
               charges+=charge;
               i--;
           }
           
       }else if(nc<59){
            i=nc;
           
           while(i>0){
               charge=0;
               charge+=10;
               if(bal<400){
                   charge+=15;
               }
               charge+=0.06;
               bal-=charge;
               charges+=charge;
               i--;
           }
       }
       else{
            i=nc;
           
           while(i>0){
               charge=0;
               charge+=10;
               if(bal<400){
                   charge+=15;
               }
               charge+=0.04;
               bal-=charge;
               charges+=charge;
               i--;
           }
       }
       
       return charges;
   }
    
}

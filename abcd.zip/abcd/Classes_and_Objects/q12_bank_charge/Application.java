/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
package bank;
import java.util.Scanner;
public class Application {    
     public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        double bal;
        int nc;
        System.out.println("Enter Initial Balance and no of cheques");
        bal=in.nextDouble();
        nc=in.nextInt();
        Bank b=new Bank(bal,nc);
        System.out.println("Charge ="+b.calFees()+"\nBalance="+b.getBalance());
        
    }
    
}

/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
package product;
import java.util.Scanner;
public class Application {
     public static void main(String[] args) {
         Product pro[]=new Product[3];
         int i;
         Scanner in=new Scanner(System.in);
         for(i=0;i<3;i++){
             String desc;
             int units;
             double price;
             
             System.out.println("Enter Description\tNo of Hands on units\t3.Price");
             
             desc=in.nextLine();
             units=in.nextInt();
             price=in.nextDouble();
             
             
             
             
             pro[i]=new Product(desc,units,price);
             
             
             System.out.println("\nDescription: "+pro[i].getDescription()+"\n"
                     + "No of Hands On units: "+pro[i].getUnits()+"\nPrice: "+pro[i].getPrice());            
          
             
         }
    }    
}

/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
package product;
public class Product {
   String description;
   int unitsOnHand;
   double price;
   Product(String description,int unitsOnHand,double price){
       this.description=description;
       this.unitsOnHand=unitsOnHand;
       this.price=price;
       
   }
   
   void setDescription(String description){
       this.description=description;
   }
   void setUnits(int unitsOnHand){
       this.unitsOnHand=unitsOnHand;
   }
   
   void setPrice(double price){
       this.price=price;
   }
   
   
   String getDescription(){
       return this.description;
   }
   
   
   int getUnits(){
       return this.unitsOnHand;
   }
    
   double getPrice(){
       return this.price;
   }
}

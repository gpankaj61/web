/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.lang.*;

class Circle
{

	private double radius;
	private final double PI = 3.14159;	
	public Circle()
	{
		radius = 0.0;
	}
	public Circle(double r)
	{
		radius = r;
	}
	
	public void setRadius(double r)
	{
		radius = r;
	}
	
	public double getRadius()
	{
		return radius;
	}
	
	public double getArea()
	{
		return PI*radius*radius;
	}
	public double getCircumference()
	{
		return PI*radius*2;
	}
	public double getDiameter()
	{
		return radius*2;
	}
	
	public static void main(String args[]) throws Exception
	{
		Circle c = new Circle();
		
		BufferedReader br = new BufferedReader( new InputStreamReader(System.in));
		
		System.out.println("Enter The radius of the circle : ");
		c.setRadius( Double.parseDouble(br.readLine()) );	
		
		System.out.println("The Details About The Following Circle  is : ");
		
		System.out.println("\n Radius : "+ c.getRadius());
		System.out.println("\n Diameter : "+ c.getDiameter());
		System.out.println("\n Circumference : "+ c.getCircumference());
		System.out.println("\n Area : "+ c.getArea());	
	}
	
}

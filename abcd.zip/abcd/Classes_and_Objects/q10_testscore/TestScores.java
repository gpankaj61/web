/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
package testscores;
public class TestScores {
   int score;
   
   TestScores(int score){
       this.score=score;
   }
   
   void setScore(int score){
       this.score=score;
   }
   
   int getScore(){
       return this.score;
   }
   
    
}

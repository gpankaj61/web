/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
package testscores;
import java.util.Scanner;
public class Application {
     public static void main(String[] args) {
        // TODO code application logic here
        TestScores test[]=new TestScores[3];
        int i;
        Scanner in=new Scanner(System.in);
        for(i=0;i<3;i++){
           int score; 
            System.out.println("Enter Score");
            score=in.nextInt();
            
            
            test[i]=new TestScores(score);
            
            
            
        }
        
        System.out.println("Average="+(test[0].getScore()+test[1].getScore()+test[2].getScore())/3);
        
        
    }
    
}

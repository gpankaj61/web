/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.lang.*;
import java.io.*;

class Employee 
{
	private String name;
	private int eid;
	private String Department;
	private String position;
	
	public Employee(String nm,int id,String dep,String pos)
	{
		name = nm;
		eid = id;
		Department = dep;
		position = pos; 
	}
	public Employee(String nm, int id)
	{
		name = nm;
		eid = id;
		Department = "";
		position = "";
	}
	public Employee()
	{
		name = "";
		eid = 0;
		Department = "";
		position = "";	
	}
	
	public void setName(String nm)
	{
		name =  nm;
	}
	
	public void seteid(int id)
	{
		eid =  id;
	}
	
	public void setDepartment(String dep)
	{
		Department =  dep;
	}
	
	public void setPosition(String pos)
	{
		position = pos;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public int geteid()
	{
		return this.eid;
	}
	
	public String getDepartment()
	{
		return this.Department;
	}
	
	public String getPosition()
	{
		return this.position;
	}	 	
}

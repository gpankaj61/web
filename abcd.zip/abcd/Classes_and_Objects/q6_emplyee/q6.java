/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
//import Employee.*;
import java.lang.*;
class q6 {
	
	public static void main(String args[])
	{
		Employee e1,e2,e3;
		
		System.out.println("Craeting Employee Objects : ");
		
		e1= new Employee("Susan Meyers",47899,"Accounting","Vice President");
		
		e2= new Employee("Mark Jones Joy",39119,"IT","Programmer");
		
		e3= new Employee("Rogers",81774,"Manufacturing","Engineer");	
		
		System.out.println("Employee Details : ");
		
		System.out.println("\nEmployee 1: \n Name : "+e1.getName()+"\n EID : "+e1.geteid()+"\n Department : "+e1.getDepartment()+"\nPosition : "+e1.getPosition());
		System.out.println("\nEmployee 2: \n Name : "+e2.getName()+"\n EID : "+e2.geteid()+"\n Department : "+e2.getDepartment()+"\nPosition : "+e2.getPosition());
		System.out.println("\nEmployee 1: \n Name : "+e3.getName()+"\n EID : "+e3.geteid()+"\n Department : "+e3.getDepartment()+"\nPosition : "+e3.getPosition());		
	}		
}

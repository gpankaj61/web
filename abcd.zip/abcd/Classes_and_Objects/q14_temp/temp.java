/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */

import java.io.*;
class temp
{
	double t;
	public temp(double t)
	{
		this.t=t;
	}
	public temp()
	{
		t=0.0;
	}
	public void setTemp(double t)
	{
		this.t = t;
	}
	public double getTemp()
	{
		return this.t;
	}
	
	public boolean isEthylFreezing()
	{
		if(t<= -173 ) return true;
		else return false;	
	}
	
	public boolean isEthylBoiling()
	{
		if(t>= 172) return true;
		else return false;	
	}
	
	public boolean isOxygenFreezing()
	{
		if(t<= -362) return true;
		else return false;	
	}
	
	public boolean isOxygenBoiling()
	{
		if(t>= -306) return true;
		else return false;	
	}
	
	public boolean isWaterFreezing()
	{
		if(t<= 32 ) return true;
		else return false;	
	}
	
	public boolean isWaterBoiling()
	{
		if(t>= 212) return true;
		else return false;	
	}
	
	public static void main(String args[]) throws Exception
	{
		temp c = new temp();
		
		BufferedReader br = new BufferedReader( new InputStreamReader(System.in));
		
		System.out.println("Enter The Temperature : ");
		c.setTemp( Double.parseDouble(br.readLine()) );
		
		System.out.println("\nAt This Temperature : ");
		
		if(c.isEthylFreezing()) System.out.println(" Ethyl Alcohol Freezes.");
		if(c.isOxygenFreezing()) System.out.println(" Oxygen Freezes.");
		if(c.isWaterFreezing()) System.out.println(" Water Freezes.");
		
		if(c.isEthylBoiling()) System.out.println(" Ethyl Alcohol Boils.");
		if(c.isOxygenBoiling()) System.out.println(" Oxygen Boils.");
		if(c.isWaterBoiling()) System.out.println(" Water Boils.");
			
	}
}

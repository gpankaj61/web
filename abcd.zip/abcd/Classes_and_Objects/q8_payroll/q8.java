/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.lang.*;
class q8 {
	
	public static void main (String args[]) throws Exception
	{
		
		
		System.out.println("Craeting Payroll Objects : ");
		
		BufferedReader br = new BufferedReader( new InputStreamReader(System.in));
		
		System.out.println("\n Enter the Name of Employee : ");
		
		String str = br.readLine();
		
		System.out.println("Enter the Employee ID :  ");
		
		int id = Integer.parseInt( br.readLine() );
		
		Payroll p1 = new Payroll(str,id); 
		
		System.out.println("Enter the hours Worked : ");
		
		p1.sethoursworked( Integer.parseInt(br.readLine()) );
		
		System.out.println("Enter the pay rate : ");
		
		p1.setpayrate( Double.parseDouble(br.readLine()) );
		
		
		System.out.println("Employee Details : ");
		
		System.out.println("\n Name : "+ p1.getName());
		System.out.println("\n EID : "+ p1.geteid());
		System.out.println("\n Hours Worked : "+ p1.gethoursworked());
		System.out.println("\n Pay rate : "+ p1.getpayrate());
		System.out.println("\n Gross Pay : "+ p1.getGrossPay());
	}
}

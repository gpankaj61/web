/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
class Payroll
{
	private String ename;
	private int eid;
	private double payRate;
	private int hoursWorked;
	
	public Payroll(String name,int id)
	{
		ename = name;
		eid = id;
		payRate=0.0;
		hoursWorked=0;
	}
	
	public void setpayrate(double rate)
	{
		payRate = rate;
	}
	
	public void sethoursworked(int hrs)
	{
		hoursWorked = hrs;
	}
	
	public String getName()
	{
	
		return this.ename;
	}
	public int gethoursworked()
	{
		return this.hoursWorked;
	}
	
	public double getpayrate()
	{
		return this.payRate;
	}
	
	public int geteid()
	{
		return this.eid;
	}
	
	public getGrossPay()
	{
		return this.hoursWorked * this.payRate;
	}
	
}

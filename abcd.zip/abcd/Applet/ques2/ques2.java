/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.applet.Applet;  
import java.awt.*;  
public class ques2 extends Applet{  
  public void paint(Graphics g) {
g.setColor(Color.cyan);
g.fillRect(0,0,600,370);

g.setColor(Color.yellow);
g.fillRect(50,150,50,100);
g.setColor(Color.red);
g.fillRect(100,150,100,100);

g.setColor(Color.black);
g.fillRect(65,200,20,50);
  
g.setColor(Color.white);
g.fillRect(125,170,50,30);

g.setColor(Color.black);
g.drawLine(50,150,75,100);//triangle top
g.drawLine(75,100,100,150);

g.drawLine(75,100,175,100);//right top
g.drawLine(175,100,200,150);

g.drawLine(95,100,120,150);//four slanting lines
g.drawLine(115,100,140,150);
g.drawLine(135,100,160,150);
g.drawLine(155,100,180,150);

g.fillOval(70,125,10,10);//circle inside hut

g.setColor(Color.orange);//sun
g.fillOval(400,50,50,50);

g.setColor(Color.green);
g.fillArc(350,330,100,50,0,180);//island
g.fillArc(420,330,100,50,0,180);
g.fillArc(500,330,100,50,0,180);
g.fillArc(550,330,150,50,0,180);
g.fillArc(200,330,200,50,0,180);

g.setColor(Color.black);//flower1
g.drawLine(400,330,400,250);
g.setColor(Color.pink);
g.fillOval(395,205,10,10);
g.fillOval(395,220,10,10);
g.fillOval(395,235,10,10);

g.fillOval(380,210,10,10);
g.fillOval(380,225,10,10);
g.fillOval(410,210,10,10);
g.fillOval(410,225,10,10);


g.setColor(Color.black);//flower2
g.drawLine(500,330,500,250);
g.setColor(Color.magenta);
g.fillOval(495,205,10,10);
g.fillOval(495,220,10,10);
g.fillOval(495,235,10,10);

g.fillOval(480,210,10,10);
g.fillOval(480,225,10,10);
g.fillOval(510,210,10,10);
g.fillOval(510,225,10,10);

g.setColor(Color.green);
g.fillArc(387,280,50,50,60,60);
g.fillArc(487,280,50,50,60,60);

}
}  

import java.applet.*;
import java.awt.*;
public class Third extends Applet{
public void paint(Graphics g){
g.setColor(Color.blue);
g.fillOval(100,11,355,355);

g.setColor(Color.cyan);

g.fillOval(103,90,130,130);
g.fillOval(321,90,130,130);
g.fillOval(149,220,130,130);
g.fillOval(279,216,130,130);
g.fillOval(215,11,130,130);
int[] a={277,257,268,291,296};

int[] a1={277,257,244,250,277};
int[] a2={257,268,256,236,235};
int[] a3={268,291,294,279,260};
int[] a4={291,296,323,319,309};
int[] a5={277,296,316,314,287};

int[] b={173,183,206,204,181};

int[] b1={173,183,164,146,149};
int[] b3={206,204,225,237,226};
int[] b2={183,206,216,210,189};
int[] b4={204,181,184,206,218};
int[] b5={173,181,172,151,152};
g.setColor(Color.magenta);

g.fillPolygon(a,b,5);
g.setColor(Color.red);

g.fillPolygon(a1,b1,5);
g.fillPolygon(a2,b2,5);
g.fillPolygon(a3,b3,5);
g.fillPolygon(a4,b4,5);
g.fillPolygon(a5,b5,5);
}

}

/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.applet.Applet;  
import java.awt.*;  
      
public class ques1 extends Applet{  
      
    public void paint(Graphics g){  
    
    	g.drawLine(100,20,100,250);
    	g.drawLine(110,20,110,250);
    	
    	g.drawLine(100,20,105,15);
    	g.drawLine(110,20,105,15);		//flag_stupa
    	
    	g.drawRect(114,20,140,35);
      	
    	g.drawRect(114,55,140,35);
    		    	
    	g.drawRect(114,90,140,35);
    	
    	g.drawRect(50,250,110,15);		//flag_stand
    	
    	
    		    		
     	g.setColor(Color.ORANGE);
    	g.fillRect(115,21,138,33);
    	
    	g.setColor(Color.white);
    	g.fillRect(115,56,139,34);
    	
    	g.setColor(Color.green.darker());
    	g.fillRect(115,91,139,34);
    	
    	g.setColor(Color.black);
    	g.drawOval(164,55,40,35);		//Ashok_chakra
    	g.drawLine(164,72,204,72);
    	g.drawLine(170,60,198,85);
    	g.drawLine(170,85,195,55);
    	
    	
    }  
}  

/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
class Fuelguage{
private int fuel;
public Fuelguage(int fuel){
	this.fuel=fuel;
}
public void increase(){
	if(fuel<15)
		fuel++;
}
public void decrease(){
	if(fuel>0)
		fuel--;
}
public int getFuel(){
	return fuel;
}


}

class Odometer{
	private int mileage;
	public Odometer(int mileage){
	this.mileage=mileage;
	}
	public void increase(){
		if(mileage<1000000)
			mileage++;
		else
			mileage=0;
	}
	public int getMileage(){
		return mileage;
	}
	public void consume(Fuelguage obj){
		if(mileage%24==0)
		obj.decrease();
	}
}

public class Car{

	public static void main(String[] args)
	{
		Fuelguage guage=new Fuelguage(12);
		Odometer odometer=new Odometer(0);
		for(int i=1;i<500&&guage.getFuel()>0;i++)
		{
			odometer.increase();
			odometer.consume(guage);
			System.out.println("Odometer="+odometer.getMileage()+"  Fuel="+guage.getFuel());
		}
	}
}
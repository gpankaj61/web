/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
class LandTract{
private double length;
private double width;
public double getArea(){
return length*width;
}
public boolean equals(){
	return length==width;

}
public void setWidth(double width){
	this.width=width;

}
public void setLength(double length){
	this.length=length;

}

	public static void main(String[] args)
	{
		LandTract a = new LandTract();
		System.out.println("enter length and width of land:");
		Scanner sc= new Scanner(System.in);
		double len=sc.nextDouble();
		double wid=sc.nextDouble();
		a.setLength(len);
		a.setWidth(wid);
		System.out.println("Area: "+a.getArea());
		if(a.equals() == true )
			System.out.println("Equals");
		else
			System.out.println("Not equal");
	}
}
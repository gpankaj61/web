/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
import java.lang.Math.*;
class TheParkedCarClass{

	public TheParkedCarClass(String make, String model, String color, String licenseNum, int minutes) {
		super();
		this.make = make;
		this.model = model;
		this.color = color;
		this.licenseNum = licenseNum;
		this.minutes = minutes;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getLicenseNum() {
		return licenseNum;
	}
	public void setLicenseNum(String licenseNum) {
		this.licenseNum = licenseNum;
	}
	public int getMinutes() {
		return minutes;
	}
	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}
	private String make;
	private String model;
	private String color;
	private String licenseNum;
	private int minutes;
	
	
}
class TheParkingMeterClass{
	public TheParkingMeterClass(int parkTime){
		this.parkTime=parkTime;
	}
	public int getParkTime() {
		return parkTime;
	}

	public void setParkTime(int parkTime) {
		this.parkTime = parkTime;
	}

	int parkTime;
}
class TheParkingTicketClass{
	public TheParkingTicketClass(TheParkedCarClass car, ThePoliceOfficerClass officer,
			TheParkingMeterClass meter) {
		super();
		this.car = car;
		this.officer = officer;
		this.meter = meter;
		this.fine =getFine();
	}
	public TheParkingMeterClass getMeter() {
		return meter;
	}
	public void setMeter(TheParkingMeterClass meter) {
		this.meter = meter;
	}
	public TheParkedCarClass getCar() {
		return car;
	}
	public void setCar(TheParkedCarClass car) {
		this.car = car;
	}
	public int getFine() {
		int fine=0;
		int extra=car.getMinutes()-meter.getParkTime();
		if(extra>0)
			fine=25;
		extra-=60;
		if(extra>0)
		{
			fine+=10*(Math.ceil(extra/60.0));
		}
		return fine;
	}
	public void setFine(int fine) {
		this.fine = fine;
	}
	public ThePoliceOfficerClass getOfficer() {
		return officer;
	}
	public void setOfficer(ThePoliceOfficerClass officer) {
		this.officer = officer;
	}
	private TheParkedCarClass car;
	private int fine;
	private ThePoliceOfficerClass officer;
	private TheParkingMeterClass meter; 
	
}
class ThePoliceOfficerClass{
	public ThePoliceOfficerClass(String name,String badge){
		this.name=name;
		this.badge=badge;

	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBadge() {
		return badge;
	}
	public void setBadge(String badge) {
		this.badge = badge;
	}
	public boolean isExpired(TheParkedCarClass car,TheParkingMeterClass meter)
	{
		return car.getMinutes()>meter.getParkTime();

	}
	public TheParkingTicketClass getParkingTicket(TheParkedCarClass car,TheParkingMeterClass meter)
	{
		TheParkingTicketClass ticket=new TheParkingTicketClass(car,this,meter);
		return ticket;
	}

	private String name;
	private String badge;
}


public class Police{

	public static void main(String[] args) {
		TheParkedCarClass car=new TheParkedCarClass("2007","diesel","Black","123435",145);
		TheParkingMeterClass meter=new TheParkingMeterClass(60);
		ThePoliceOfficerClass officer=new ThePoliceOfficerClass("amit","inspector");
		if(officer.isExpired(car,meter)==true)
		{
			TheParkingTicketClass ticket=officer.getParkingTicket(car,meter);
			System.out.println("fine="+ticket.getFine());
		}


	}

}

/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
import java.lang.Math.*;
class Area{
	public static double getArea(double radius){
		return Math.PI * radius*radius;
	}
	public static double getArea(double pi,double radius,double height){
		return pi* radius * radius * height;
	}
	public static double getArea(double length,double breadth){
		return length*breadth;
	}
	
	public static void main(String[] args)
	{
		System.out.println("Area of circle: "+ Area.getArea(12));
		System.out.println("Area of cylinder: "+ Area.getArea(Math.PI,12,45));
		System.out.println("Area of rectangle: "+ Area.getArea(15,46));

	}
}
/*
 * Pankaj Kumar Gupta 
 * 20144009 
 CS3 
 */
import java.io.*;
import java.util.*;
import java.lang.Math.*;
class Area{
	public static double getArea(double radius){
		return Math.PI * radius*radius;
	}
	public static double getArea(double half,double base,double height){
		return half * base * height;
	}
	public static double getArea(double length,double breadth){
		return length*breadth;
	}
	
	public static void main(String[] args)
	{
		
		while(true){
		System.out.println("Geometry Calculator\n1. Calculate the Area of a Circle\n2. Calculate the Area of a Rectangle\n3. Calculate the Area of a Triangle\n4. Quit\nEntre your choice (1 - 4):");
	double rad,length,width,base,height;
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		switch(choice){
			case 1: System.out.print("Enter radius:");rad=sc.nextDouble();
		System.out.println("Area of circle: "+ Area.getArea(rad)); break;
			case 2: System.out.print("Enter length and width:");length=sc.nextDouble();width=sc.nextDouble();
		System.out.println("Area of rectangle: "+ Area.getArea(length,width));break;
			case 3: System.out.print("Enter base and height:");base=sc.nextDouble();height=sc.nextDouble();
		System.out.println("Area of Triangle: "+ Area.getArea(0.5,base,height));break;
			case 4: return ;
		}
	}
	}
}